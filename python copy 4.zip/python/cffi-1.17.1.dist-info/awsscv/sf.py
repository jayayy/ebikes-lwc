import os, logging, json, requests
from .sf_config import SalesforceConfig
from .sf_auth import SalesforceAuth, AuthError

logger = logging.getLogger()


class Salesforce:
    def __init__(self):
        logger.setLevel(logging.getLevelName(os.getenv('lambda_logging_level', 'INFO')))
        self.request = Request()
        self.init_request(refresh=False)

    def search(self, query):
        logger.debug("Salesforce: Search")
        resp = self.execute(self.request.get,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/search',
                            params={'q': query})

        d = resp.json()

        return d['searchRecords']

    def query(self, query):
        logger.debug("Salesforce: Query")
        resp = self.execute(self.request.get,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/query',
                            params={'q': query})

        d = resp.json()

        for record in d['records']:
            del record['attributes']

        return d['records']

    def parameterized_search(self, params):
        logger.debug("Salesforce: Parameterized Search")
        resp = self.execute(self.request.get,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/parameterizedSearch',
                            params=params)

        d = resp.json()

        for record in d['searchRecords']:
            del record['attributes']

        return d['searchRecords']

    def update(self, sobject, sobject_id, data):
        logger.debug("Salesforce: Update")
        resp = self.execute(self.request.patch,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/sobjects/%s/%s' % (
                            sobject, sobject_id),
                            data=data)

        return resp.status_code

    def update_by_external(self, sobject, field, sobject_id, data):
        logger.debug("Salesforce: Update by External")
        resp = self.execute(self.request.patch,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/sobjects/%s/%s/%s' % (
                            sobject, field, sobject_id),
                            data=data)

        return resp.status_code;

    def create(self, sobject, data):
        logger.debug("Salesforce: Create")
        resp = self.execute(self.request.post,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/sobjects/%s' % sobject,
                            data=data)

        d = resp.json()

        return d['id']

    def delete(self, sobject, sobject_id):
        logger.debug("Salesforce: Delete")
        resp = self.execute(self.request.delete,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/sobjects/%s/%s' % (
                            sobject, sobject_id))

        return resp.status_code

    def call_flow(self, sflow, data):
        logger.debug("Salesforce: Call Flow")
        resp = self.execute(self.request.post,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/actions/custom/flow/%s' % sflow,
                            data={"inputs": data})

        d = resp.json()

        return d

    def create_simple_chatter_post(self, group_id, message):
        logger.debug("Salesforce: Create Simple Chatter Post")
        data = {
            "body": {
                "messageSegments": [
                    {
                        "type": "Text",
                        "text": message
                    }
                ]
            },
            "feedElementType": "FeedItem",
            "subjectId": group_id,
            "visibility": "InternalUsers"
        }

        resp = self.execute(self.request.post,
                            url=SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE + '/chatter/feed-elements',
                            data=data)

        d = resp.json()

        return d

    def init_request(self, refresh=False):
        self.access_token = SalesforceAuth().get_access_token(refresh=refresh)
        self.headers = {
            'Authorization': 'Bearer %s' % self.access_token,
            'Content-Type': 'application/json'
        }

    def execute(self, method, **kwargs):
        try:
            return method(**kwargs, headers=self.headers)
        except AuthError as ae:
            self.init_request(refresh=True)
            return method(**kwargs, headers=self.headers)


class Request:
    def post(self, url, headers, data=None, params=None, hideData=False):
        logger.debug('POST Requests:\nurl=%s' % url)
        if not hideData:
            logger.debug("data=%s\nparams=%s" % (data, params))
        r = requests.post(url=url, data=json.dumps(data), params=params, headers=headers)
        if not hideData:
            logger.debug("Response: %s" % r.text)

        return __check_resp__(r)

    def delete(self, url, headers):
        logger.debug("DELETE Requests:\nurl=%s" % url)
        r = requests.delete(url=url, headers=headers)
        logger.debug("Response: %s" % r.text)

        return __check_resp__(r)

    def patch(self, url, data, headers):
        logger.debug("PATCH Requests:\nurl=%s\ndata=%s" % (url, data))
        r = requests.patch(url=url, data=json.dumps(data), headers=headers)
        logger.debug("Response: %s" % r.text)

        return __check_resp__(r)

    def get(self, url, params, headers):
        logger.debug("GET Requests:\nurl=%s\nparams=%s" % (url, params))
        r = requests.get(url=url, params=params, headers=headers)
        logger.debug("Response: %s" % r.text)

        return __check_resp__(r)


class HttpError(Exception):
    def __init__(self, status_code, error, error_description, retry=True):
        self.status_code = status_code
        self.error = error
        self.error_description = error_description
        self.retry = retry


def __check_resp__(resp):
    logger.debug(resp)

    if resp.status_code // 100 == 2:
        return resp

    if resp.status_code == 401:
        raise AuthError('')

    data = resp.json()

    if 'error' in data:
        raise HttpError(resp.status_code, data['error'], data['error_description'],
                        (True, False)[resp.status_code == 401])

    if isinstance(data, list):
        for error in data:
            raise HttpError(resp.status_code, data['error'], data['error_description'],
                            (True, False)[resp.status_code == 401])

    raise HttpError(resp.status_code, 'Unknown error', 'request returned status code: %d' % resp.status_code,
                    (True, False)[resp.status_code == 401])
