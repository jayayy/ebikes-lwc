import os


class SalesforceConfig:
    # Set on Lambda
    SECRET_ID = os.getenv('sf_config_sm_arn')

    # Obtained from Secrets Manager
    PRIVATE_KEY_PROP = 'PrivateKey'
    CONSUMER_KEY_PROP = 'ConsumerKey'
    OAUTH_TOKEN_PROP = 'OAuthToken'
    HOST_PROP = 'Host'
    USERNAME_PROP = 'Username'
    VERSION_PROP = 'Version'
    MODE_PROP = 'Mode'
    REGION_PROP = 'Region'

    # Static Values
    AUDIENCES = {
        'PROD': 'https://login.salesforce.com',
        'DEV': 'https://login.salesforce.com',
        'SANDBOX': 'https://test.salesforce.com'
    }

    TOKEN_VALID_FOR = 2  # Value in minutes

    SALESFORCE_REST_API_ENDPOINT_BASE = ''
