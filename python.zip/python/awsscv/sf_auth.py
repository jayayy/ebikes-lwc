import os, logging, json, boto3, requests, base64, jwt
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from .sf_config import SalesforceConfig

logger = logging.getLogger()

client = boto3.client(
    service_name='secretsmanager',
    region_name='us-west-2'
)


class SalesforceAuth:
    def __init__(self):
        logger.setLevel(logging.getLevelName(os.getenv('lambda_logging_level', 'INFO')))

    def get_access_token(self, refresh=False):
        settings = self.get_settings()

        SalesforceConfig.SALESFORCE_REST_API_ENDPOINT_BASE = settings[SalesforceConfig.HOST_PROP] + \
                                                             '/services/data/' + \
                                                             settings[SalesforceConfig.VERSION_PROP]

        access_token = settings[SalesforceConfig.OAUTH_TOKEN_PROP]

        if refresh is True:
            logger.debug("Creating new access token...")
            exp = int((datetime.utcnow() + timedelta(minutes=SalesforceConfig.TOKEN_VALID_FOR)).timestamp())

            mode = settings[SalesforceConfig.MODE_PROP]

            if mode is None:
                mode = SalesforceConfig.AUDIENCES.PROD

            audience = SalesforceConfig.AUDIENCES[mode]

            jwt_payload = {
                'iss': settings[SalesforceConfig.CONSUMER_KEY_PROP],
                'sub': settings[SalesforceConfig.USERNAME_PROP],
                'aud': audience,
                'exp': exp
            }

            logger.debug(jwt_payload)

            token = self.generate_jwt(jwt_payload, base64.b64decode(settings[SalesforceConfig.PRIVATE_KEY_PROP]))

            logger.debug(token)

            resp = requests.post(
                audience + '/services/oauth2/token',
                data='grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + token,
                headers={'Content-Type': 'application/x-www-form-urlencoded'}
            )

            logger.debug(resp)

            if resp.status_code >= 400:
                raise AuthError('')

            access_token = resp.json()['access_token']

            settings[SalesforceConfig.OAUTH_TOKEN_PROP] = access_token

            client.update_secret(
                SecretId=SalesforceConfig.SECRET_ID,
                SecretString=json.dumps(settings)
            )
            return access_token
        else:
            logger.debug("Using current access token...")
            return access_token

    def get_settings(self):
        try:
            response = client.get_secret_value(SecretId=SalesforceConfig.SECRET_ID)

            response_value = response['SecretString']

            return json.loads(response_value)

        except ClientError as e:
            raise e

    def generate_jwt(self, payload, private_key):
        return jwt.encode(payload, private_key, algorithm='RS256')


class AuthError(Exception):
    pass
